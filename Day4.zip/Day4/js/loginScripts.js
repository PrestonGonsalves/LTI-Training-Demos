// loginScripts.js -- External javascript

function verifyLogin(loginForm){
    if(loginForm.checkValidity()){
        var username = loginForm.txtUN.value;
        var password = loginForm.txtPwd.value;

        // == -> Checks value
        // === -> Checks datatype
        if(username === "admin@gmail.com" && password === "123"){
            alert('Login Successful..!');
            // this is temporary storage as soon as you can 
            // window, it will destroy
            // sessionStorage.setItem("username",username);     // once window is closed, session storage is cleared
            localStorage.setItem("username",username);
            localStorage.setItem("pwd",password);
            window.open("../pages/simpleInterest.html");   //window.location means URL
            
        }
        else{
            alert('Invalid Username or Password..!');
        }
    }
}

function countHits(){
    // if(localStorage.getItem("hitcount")!=null)
    // OR
    if(localStorage.hitscount){
        localStorage.hitscount = Number(localStorage.hitscount) + 1;
    }
    else{
        localStorage.hitscount = 1;
    }
}

