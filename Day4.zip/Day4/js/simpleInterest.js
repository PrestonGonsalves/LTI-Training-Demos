function simpleInterest(pr, r, y){
    principal = parseFloat(pr.value);
    roi = parseFloat(r.value);
    years = parseFloat(y.value);

    result = (principal * roi * years)/100;

    //alert('Simple Interest is ' + result);

    document.getElementById("result").innerHTML="Simple Interest is Rs."+result+"/-";
}

function clearText(){
    document.getElementById("result").innerText="";
}

function countVisits(){
    // if(localStorage.getItem("hitcount")!=null)
    // OR
    if(localStorage.visitscount){
        localStorage.visitscount = Number(localStorage.visitscount) + 1;
    }
    else{
        localStorage.visitscount = 1;
    }

    document.getElementById("visitCount").innerText="Visit counts: "+localStorage.visitscount;
}

function logOff(){
    if(localStorage.username){
        localStorage.removeItem("username");    //To remove items individually by KEYNAME
        localStorage.clear();                   //Removing alll keys with CLEAR function
        window.open("../pages/simpleInterestHome.html");
    }
}